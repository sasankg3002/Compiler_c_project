#include "types.h"
#include "stat.h"
#include "user.h"
#include <stddef.h>

int
main(int argc, char *argv[])
{
  int f = fork();
  if(f == 0){
    //   char * args[]= {argv[2],NULL};
    // printf(1,"%d",argc);
    // printf(1,"%s",argv[1]);
    if(argc == 2){
        // printf(1,"hello");
        exec(argv[1],&argv[1]);
    }
    else{
        // int n = argc-1;
        // char* args[n+1];
        // for(int i=0;i<n;i++){
        //     args[i] = argv[i+2];
        // }
        // args[n] = NULL;
        exec(argv[1],&argv[1]);
    }
    exit();
  }
  else{
      wait();
    //   printf(1, "Hello\n");
      exit();
  }
}
