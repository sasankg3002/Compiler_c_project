#include<stdio.h>
#include<signal.h>
#include<wait.h>
#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include<strings.h>
// #include "stdafx.h"
// #include <iostream>


int main(int argc, char* argv[]){
    
    int x;
    x = atoi(argv[1]);
    kill(x, SIGINT);
    kill(x, SIGTERM);
    kill(x, SIGKILL);

}