/* tour.c
* To learn the basic signal handling in c
* Can send the interrupt signal via Ctrl-c in a terminal.
*
* Complete TODO items for this question
*/

#include <stdio.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdlib.h>

#define NUM_FRIEND 5 // Number of friends visiting the Dinosaurs Park

int friend_count = 0; // Current count of friends completed the tour

// TODO: Add a signal handling function which handle SIGINT and SIGCHLD signals

void signal_handler(int sig){
    printf("you have interrupted the process\n");
    if(friend_count < NUM_FRIEND){
        printf("Only %d of the five friends have visited the diniosaur park\n", friend_count);
    }
    return;
}

void handler(int sig){
    return;
}

void catcher( int sig ) {
    printf( "inside catcher() function\n" );
}

// END TODO
int main(int argc, char *argv[])
{

    printf("Welcome to the Dinosaurs Park.\n");

    /* 
    * TODO: add struct/calls to sigaction() to handle SIGINT and SIGCHLD. 
    * Use sigaction() and associated structs.
    * Ensure that the flag SA_RESTART is set as well to ensure system calls are automatically restarted.
    */
    
    // signal(SIGCHLD,signal_handler);
    // END TODO
    signal(SIGINT,signal_handler);
    int arr[5];
    printf("The Process ID of Dinosaurs Park: %d \n", getpid());
    for (size_t friend = 1; friend <= NUM_FRIEND; friend++)
    {
        int n = fork();
        if (n == 0)
        {
            //TODO Note that, you must carefully place the various children in different process groups 
            // that is different from the default process group of its parent
            //say, using the setpgid system call.
            // arr[friend-1] = getpid();
            // sleep emulates "touring" time
            // sigset_t sigset;
            // sigfillset(&sigset);
            // sigprocmask(SIG_SETMASK, &sigset, NULL);
            // time_t start, finish;
            struct sigaction sact;
            sigset_t new_set, old_set;
            double diff;

            sigemptyset( &sact.sa_mask );
            sact.sa_flags = 0;
            sact.sa_handler = catcher;
            sigaction( SIGINT, &sact, NULL );

            sigemptyset( &new_set );
            sigaddset( &new_set, SIGINT );
            sigprocmask( SIG_BLOCK, &new_set, &old_set);
            // signal(SIGCHLD,signal_handler);

            sleep(5 * friend);

            printf("Friend #%zu with process ID - %d has completed the tour.\n", friend, getpid());
            
            // wait(NULL);
            exit(0);
            //END TODO
        }
        arr[friend-1] = n;
    }

    // signal(SIGCHLD,signal_handler);
    int status;
    for(int i=0;i<5;i++){
        waitpid(arr[i],&status, WUNTRACED);
        friend_count++;
    }
    printf("Thank you for RIDING with us:)))))\n");

    // wait for all friends to complete tour
    return 0;
}
