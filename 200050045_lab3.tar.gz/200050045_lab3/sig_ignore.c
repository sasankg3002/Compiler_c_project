#include<stdio.h>
#include<signal.h>
#include<wait.h>
#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>

void handler(int sig){
    return;
}

int main(){
    printf("Process ID %d\n",getpid());
    signal(SIGTERM,handler);
    signal(SIGINT,handler);

    while (1)
    {
        /* code */
        sleep(3);
        printf("Waiting...\n");
    }
    
}