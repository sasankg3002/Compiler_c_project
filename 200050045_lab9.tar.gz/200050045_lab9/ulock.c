#include "ulock.h"
#include "x86.h"
#include "defs.h"

void init_lock(struct lock_t *s) {
    s->locked = 0;
}

void 
acquire_lock(struct lock_t *s) 
{
    /* Your Code */
    // The xchg is atomic.
    // pushcli(); // disable interrupts to avoid deadlock.
    // if(holding(s))
    //     panic("acquire");
    // pushcli(); // disable interrupts to avoid deadlock.
    // if(holding(s))
    //     panic("acquire");

    while(xchg(&s->locked, 1) != 0)
    ;
    __sync_synchronize();
    return;
}

void 
release_lock(struct lock_t *s) 
{
    /* Your Code */
    // if(!holding(s))
    //     panic("release");
    __sync_synchronize();
    asm volatile("movl $0, %0" : "+m" (s->locked) : );

}


void 
init_sem(struct sem_t *s, int initval)
{
    /* Your Code */
    s->val = initval;
    init_lock(&s->lk);
}

void
up_sem(struct sem_t *s) 
{
    /* Your Code */
    acquire_lock(&s->lk);
    s->val++;
    signal_sem(s);
    release_lock(&s->lk);
}

void 
down_sem(struct sem_t *s) 
{
    /* Your Code */
    acquire_lock(&s->lk);

    // if(s->val>0){
    //     s->val--;
    // }
    // else{
    //     block_sem(s);
    // }
    while(s->val==0){
        block_sem(s);
    }
    s->val--;

    release_lock(&s->lk);
}
