#include <stdio.h>
#include <sys/types.h>
#include<sys/wait.h>
#include <unistd.h>

int main(){
    int n;
    scanf("%d", &n);
    int num =fork();
    // printf("%d\n", num);
    if(num!=0){
        wait(NULL);
        for(int i=0;i<n;i++){
            int c = i+1+n;
            printf("P %d %d\n",getpid(),c);
        }
    }
    else{
        for(int i=0;i<n;i++){
            printf("C %d %d\n",getpid(),1+i);
        }
    }
}