#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>

int main(){
    int n;
    scanf("%d", &n);
    int num =fork();
    // printf("%d\n", num);
    for(int i=0;i<n;i++){
        int c = i+1+n;
        if(num !=0){
            printf("P %d %d\n",getpid(),c);
        }
        else{
            printf("C %d %d\n",getpid(),1+i);
        }
    }
}