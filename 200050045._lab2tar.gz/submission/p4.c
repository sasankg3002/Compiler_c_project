#include <stdio.h>
#include <sys/types.h>
#include<sys/wait.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h> 

int main(){
    char inp;
    scanf("%s", &inp);
    printf("%s", &inp);
    char c;
    int fd1;
    fd1 = open(&inp, O_RDONLY); 
    printf("%d",fd1);
    // printf("%d",sz);

    char out;
    scanf("%s", &out);
    printf("%s", &out);

    int fd2 = open(&out, O_WRONLY , 0644);
    printf("%d",fd2);
    while(true){
        int sz = read(fd1, &c, 2);
        printf("%d", sz);
        if(sz < 0){
            break;
        }
        int sz1 = write(fd2, &c, sz);
    }
    close(fd2);
    close(fd1);
    // system("g++ helloworld.c -o helloworld");
}