#include <stdio.h>
#include <sys/types.h>
#include<sys/wait.h>
#include <unistd.h>
#include <stdlib.h>

int main(){
    while(true){
        printf(">>> ");
        char arr[50];
        arr[0] = '.';
        arr[1] = '/';
        scanf("%s",&arr[2]);
        // printf(arr)
        // printf(arr+1);
        int num = fork();
        if(num ==0){
            char *args[]={arr,NULL};
            // printf(args[0]);
            execvp(args[0],args);
        }
        else{
            wait(NULL);
        }
    }
    // system("g++ helloworld.c -o helloworld");
}