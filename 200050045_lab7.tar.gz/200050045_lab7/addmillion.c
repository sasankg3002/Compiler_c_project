#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#include <time.h>

int account_balance = 0;
pthread_mutex_t lock;

void* increment(void* num) {
    // printf("%d\n",(*(int *)(num)));
    pthread_mutex_lock(&lock);
    for (int i = 0; i < (*(int *)(num))*1000000; i++) {
        account_balance++;
    }
    pthread_mutex_unlock(&lock);
}

int main(int argc, char* argv[]) {
    time_t start, end;
    time(&start);
    int s = clock();
    int threadNum = 10;
    int i;

    if(argc > 1){
        threadNum = atoi(argv[1]);
        printf("%d\n",threadNum);
    }
    pthread_t th[threadNum];
    int count = 2048/threadNum;

    pthread_mutex_init(&lock, NULL);
    for (i = 0; i < threadNum; i++) {
        if (pthread_create(th + i, NULL, &increment, (void *)(&count)) != 0) {
            perror("Failed to create thread");
            return 1;
        }
        printf("Transaction %d has started\n", i);
    }
    for (i = 0; i < threadNum; i++) {
        if (pthread_join(th[i], NULL) != 0) {
            return 2;
        }
        printf("Transaction %d has finished\n", i);
    }
    printf("Account Balance is : %d\n", account_balance);
    time(&end);
    int e = clock();
    printf("Time spent: %f\n", (double)(e-s)/1e6);

    pthread_mutex_destroy(&lock);
    return 0;
}

// #include <stdlib.h>
// #include <stdio.h>
// #include <pthread.h>
// #include <time.h>
// int account_balance = 0;
// pthread_mutex_t bal_lock;
// void* increment(void *n) {
//     pthread_mutex_lock(&bal_lock);
//     int times=*((int*)n);
//     while(times--){
//         for (int i = 0; i < 1000000; i++) {
//             account_balance++;
//         }
//     }
//     pthread_mutex_unlock(&bal_lock);
// }


// int main(int argc, char* argv[]) {
//     time_t start,end;
//     time(&start);
//     int threadNum=atoi(argv[1]);
//     pthread_t th[threadNum];
//     int i;
//     int to_i=2048/threadNum;
//     if (pthread_mutex_init(&bal_lock, NULL) != 0) {
//         printf("\n mutex init has failed\n");
//         return 3;
//     }
//     for (i = 0; i < threadNum; i++) {
//         if (pthread_create(th + i, NULL, &increment, &to_i) != 0) {
//             perror("Failed to create thread");
//             return 1;
//         }
//         printf("Transaction %d has started\n", i);
//     }
//     for (i = 0; i < threadNum; i++) {
//         if (pthread_join(th[i], NULL) != 0) {
//             return 2;
//         }
//         printf("Transaction %d has finished\n", i);
//     }
//     printf("Account Balance is : %d\n", account_balance);
//     time(&end);
//     printf("Time spent: %ld\n",(end-start)*1000);
//     return 0;
// }